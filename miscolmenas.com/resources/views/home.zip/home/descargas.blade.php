@extends('home.layout')
@section('content')
  <div class="colorlib-contact">
        <div class="colorlib-narrow-content">
          <div class="row">

              <img src="{{asset('home/images/construccion.png')}}" alt="">

          </div>
        </div>
      </div>


  <script src="{{ asset('js/descargas.js') }}" defer></script>
@endsection

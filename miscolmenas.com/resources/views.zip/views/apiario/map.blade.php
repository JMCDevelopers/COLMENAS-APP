
<div style="width: 100%; height: 100px;">
	{!! $map['html'] !!}
</div>
{!! $map['js'] !!}

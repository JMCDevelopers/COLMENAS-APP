@extends('layouts/dashboard')
@section('contenido')


  <!-- DETALLE DE REINA -->
  <div class="modal fade" tabindex="-1"  data-backdrop="static" role="dialog" id="modal_gestion_reina" >
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h2 class="" id="titulo">Detalle Reina Asignada a la colmena</h2>
        </div>
        <div class="modal-body" id="modal-body">

          <div class="panel panel-info">
              <div class="panel-heading">Información General</div>
              <div class="panel-body">
                <div class="" id="contenedor_detalle">

                </div>
              </div>
          </div>

          <div class="panel panel-info">
              <div class="panel-heading">Gestionar</div>
              <div class="panel-body">

                <div class="form-group col-lg-6">
                  <input type="hidden" id="id_reina" value="">
                  <input type="hidden" id="id_colmena_reina" value="">
                  <button type="button" name="button"  class="btn btn-info btn-block" onclick="LiberarReina()" >Liberar Reina</button>
                </div>
                <div class="form-group col-lg-6">
                  <button type="button" name="button" class="btn btn-danger btn-block" onclick="EliminarReina()" >Eliminar Reina</button>
                </div>
              </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

  <!-- ASIGNAR REINA  DE COLMENA -->
  <div class="modal fade" tabindex="-1"  data-backdrop="static" role="dialog" id="modal_ingreso_reina" >
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h2 class="" id="titulo">Ingresar Reina</h2>
        </div>
        <div class="modal-body" id="modal-body">

          <div class="panel panel-info">
              <div class="panel-heading">Reinas Disponibles</div>
              <div class="panel-body">
                <form class="form-inline" action="" method="post" id="frm_eventos">

                  <div class="form-group col-lg-6" id="reinas_disponibles">
                  </div>
                  <div class="form-group col-lg-6" id="contenedor_detalle_reina" >

                  </div>
                </form>
              </div>
          </div>
          <div class="panel panel-info">
              <div class="panel-heading">Registrar nueva reina y asignar</div>
              <div class="panel-body">
                <div class="table table-responsive" id="" style="font-size:11px; text-align:center; cursor: pointer">
                  <form class="" action="{{route('crear_reina_colmena')}}" method="post" id="frm_crear_reina">
                    {{ csrf_field() }}
                    <div class="col-lg-12">
                      <div class="form-group col-lg-4 {{$errors->has('identificador_reina') ? 'has-error' : ''}}">
                        <label for="identificador_reina">Nombre/Código</label>
                        <input type="hidden" name="idcolmenas" value="" id='idcolmenas_reina'>
                        <input type="text" class="form-control" id='identificador_reina' name="identificador_reina" value=""  placeholder="Nombre/Codigo">
                        {!!$errors->first('identificador_reina','<span class="help-block">:message</span>')!!}
                      </div>
                      <div class="form-group col-lg-4 {{$errors->has('fecha_nacimiento') ? 'has-error' : ''}}">
                        <label for="fecha_nacimiento">Fecha Nacimiento</label>
                        <input type="date" class="form-control" name="fecha_nacimiento" value="{{date('Y-m-d')}}"  placeholder="Fecha Nacimiiento">
                        {!!$errors->first('fecha_nacimiento','<span class="help-block">:message</span>')!!}
                      </div>
                      <div class="form-group col-lg-4 {{$errors->has('procedencia') ? 'has-error' : ''}}">
                        <label for="procedencia">Procedencia</label>
                        <select class="form-control" name="procedencia">
                          <option value="">Procedencia</option>
                          <option value="Propio">Compra</option>
                          <option value="Nueva">Nueva</option>
                          <option value="Enjambre">Enjambre</option>
                        </select>
                        {!!$errors->first('establecimiento','<span class="help-block">:message</span>')!!}
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="form-group col-lg-4 {{$errors->has('raza_reina_idraza_reina') ? 'has-error' : ''}}">
                        <label for="raza_reina_idraza_reina">Raza</label>
                        <select class="form-control" name="raza_reina_idraza_reina">
                          <option value="">Raza Reina</option>
                          @foreach ($raza as $key => $value)
                            <option value="{{$value->idraza_reina}}">{{$value->nombre}}</option>
                          @endforeach
                        </select>
                        {!!$errors->first('raza_reina_idraza_reina','<span class="help-block">:message</span>')!!}
                      </div>
                      <div class="form-group col-lg-4 {{$errors->has('tipo') ? 'has-error' : ''}}">
                        <label for="tipo">Estado</label>
                        <select class="form-control" name="tipo">
                          <option value="">Estado</option>
                            <option value="Fecundado">Fecundado</option>
                            <option value="Virgen">Virgen</option>
                        </select>
                        {!!$errors->first('tipo','<span class="help-block">:message</span>')!!}
                      </div>
                      <div class="form-group col-lg-4 {{$errors->has('descripcion') ? 'has-error' : ''}}">
                        <label for="descripcion">Descripción</label>
                        <textarea  class="form-control" name="descripcion"  placeholder="Descripción reina"></textarea>
                        {!!$errors->first('descripcion','<span class="help-block">:message</span>')!!}
                      </div>
                      <div class="form-group col-lg-2">
                        <input type="button" onclick="registrarReina()" class="btn btn-warning" name="Registrar y asignar" value="Crear y asignar">
                      </div>
                    </div>
                  </form>
                </div>
              </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->



  <!-- MODAL EVENTOS  DE COLMENA -->
  <div class="modal fade" tabindex="-1"  data-backdrop="static" role="dialog" id="modal_eventos_colmena" >
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h2 class="" id="titulo">Eventos</h2>
        </div>
        <div class="modal-body" id="modal-body">

          <div class="panel panel-info">
              <div class="panel-heading">Registrar evento</div>
              <div class="panel-body">
                <form class="form-inline" action="" method="post" id="frm_eventos">
                  <div class="form-group">
                    <label for="date">Fecha Evento:</label>
                    <input type="date" class="form-control" id="fecha" name="fecha_evento" value="{{date('Y-m-d')}}">
                  </div>
                  <div class="form-group">
                    <label for="date">Describa el evento:</label>
                    <textarea name="descripcion_evento"  id="descripcion_evento" class="form-control" cols="50"></textarea>
                    <input type="hidden" name="idcolmenas" value="" id="id_colmenas">
                  </div>
                  <div class="form-group">
                    <button type="button" name="button" class="btn btn-warning" onclick="guardarEvento()" >Guardar</button>
                  </div>
                </form>
              </div>
          </div>
          <div class="panel panel-info">
              <div class="panel-heading">Lista de eventos</div>
              <div class="panel-body">
                <div class="table table-responsive" id="contenedor_eventos" style="font-size:11px; text-align:center; cursor: pointer">

                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

  <!-- DETALLE DE COLMENA -->
  <div class="modal fade" tabindex="-1"  data-backdrop="static" role="dialog" id="modal_detalle_colmena" >
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h2 class="" id="titulo">DETALLE COLMENA</h2>
        </div>
        <div class="modal-body" id="modal-body">
            <div class="table table-responsive">
              <table class="table table-responsive table-hover table-condensed" style="border:none;color:#000;">
                <tr>
                  <td style="font-weight:bold">
                    Identificador:
                  </td>
                  <td>
                    <div id="identificador"  style="text-align: left"></div>
                  </td>
                  <td style="font-weight:bold">
                    Fecha Creación:
                  </td>
                  <td>
                    <div id="fecha_creacion"  style="text-align: left"></div>
                  </td>
                  <td style="font-weight:bold">
                    Descripción:
                  </td>
                  <td>
                    <div id="descripción"  style="text-align: left"></div>
                  </td>
                </tr>

                <tr>
                  <td style="font-weight:bold">
                    Apiario:
                  </td>
                  <td>
                    <div id="apiario_colmena"  style="text-align: left"></div>
                  </td>
                  <td style="font-weight:bold">
                    Fuerza población:
                  </td>
                  <td>
                    <div id="fuerza"  style="text-align: left"></div>
                  </td>
                  <td style="font-weight:bold">
                    Tipo Colmena:
                  </td>
                  <td>
                    <div id="tipo_colmena"  style="text-align: left"></div>
                  </td>
                </tr>
                <tr>
                  <td style="font-weight:bold">
                    Origen Colmena:
                  </td>
                  <td>
                    <div id="origen_colmena"  style="text-align: left"></div>
                  </td>
                  <td style="font-weight:bold">
                    Reina:
                  </td>
                  <td>
                    <div id="reina_colmena"  style="text-align: left"></div>
                  </td>

                </tr>
              </table>
            </div>




          <div class="panel panel-info">
              <div class="panel-heading">Detalle Ultima Inspección</div>
              <div class="panel-body">
            <div id="inspeccion_detalles" class="table table-responsive">
              <div class="row">
                  <div class="form-group col-lg-12">
                      <label for="">Fecha de inspección:</label>
                      <span id="fecha_inspeccion_detalle"> sjjs</span>
                  </div>
              </div>
              <div class="row">
                <div class="form-group col-lg-3">
                    <label for="">Reina:</label>
                    <span class="text-danger" id="reina_detalle">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Postura:</label>
                    <span class="text-danger" id="postura">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Cria sellada:</label>
                    <span class="text-danger" id="cria_sellada">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Cria nacida:</label>
                    <span class="text-danger" id="cria_nacida">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Fuerza población:</label>
                    <span class="text-danger" id="fuerza_poblacion">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Temperamento colmena:</label>
                    <span class="text-danger" id="temperamento">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Número de marcos:</label>
                    <span class="text-danger" id="marcos">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Reservas polen:</label>
                    <span class="text-danger" id="polen">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Reservas miel:</label>
                    <span class="text-danger" id="miel">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Albeolos/Celdas reales:</label>
                    <span class="text-danger" id="albeolos">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Olor:</label>
                    <span class="text-danger" id="olor">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Estado material:</label>
                    <span class="text-danger" id="material">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Clima:</label>
                    <span class="text-danger" id="clima">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Descripcion clima:</label>
                    <span class="text-danger" id="descripcion_clima">sjjs</span>
                </div>
                <div class="form-group col-lg-3">
                    <label for="">Observaciones:</label>
                    <span class="text-danger" id="observaciones">sjjs</span>
                </div>
              </div>
            </div>
            <div class="row col-lg-6">
              <div class="title text-info">
                Condiciones de la colmena
              </div>
              <hr>
              <div id="contenedor_condiciones" class="table table-responsive">

              </div>
            </div>
            <div class="row col-lg-6">
              <div class="title text-info">
                Enfermedades presentes en la colmena
              </div>
              <hr>
              <div id="contenedor_enfermedades" class="table table-responsive">

              </div>
            </div>
            <div class="row col-lg-6 ">
              <div class="tittle text-info">
                Tratamientos
              </div>
              <hr>
              <div id="contenedor_tratamientos" class="table table-responsive">

              </div>
            </div>

            <div class="row col-lg-6">
              <div class="title text-info">
                Alimentos proporcionados
              </div>
              <hr>
              <div id="contenedor_alimentos" class="table table-responsive">

              </div>
            </div>

            <div class="row col-lg-12">
              <div class="title text-info">
                Imagenes de la inspeccion
              </div>
              <hr>
              <div id="contenedor_imagenes_inspeccion" class="table table-responsive">

              </div>
            </div>


              </div>
          </div>
          <div class="panel panel-info">
              <div class="panel-heading">Eventos de la eventos de la Colmena</div>
              <div class="panel-body">

              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->


  <!-- Modal Editar -->
  <div id="modal_componentes" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Componentes de la colmena</h4>
        </div>
        <div class="modal-body" id="contenedor_componentes">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>

    </div>
  </div>
  <!--fin modal-->

  <div class="row">
    <ol class="breadcrumb">
      <li><a href="{{route('dashboard')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
      <li class="active">Colmenas</li>
    </ol>
  </div>

  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Seleccion colmenas por apiario</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Mostrar Tabla">
          <i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Quitar Tabla">
            <i class="fa fa-times"></i></button>
        </div>
      </div>
        <div class="box-body">
          <div class="panel panel-default">
            <div class="panel-body">

                <div class="form-group col-lg-1">
                  <label class="" for="apiario">APIARIO</label>
                </div>
                <div class="form-group col-lg-4">
                  <select class="form-control" name="idapiario" id="idapiario" onchange="ConsultarPorApiario(this.value)">
                    <option value="">
                      - Selecciona un apiario-
                    </option>
                    @foreach ($apiarios as $key => $value)
                      <option value="{{$value->idapiario}}">{{$value->nombre_apiario}}</option>
                    @endforeach
                    <option value="">
                      TODO
                    </option>
                  </select>
                </div>
                <div class="form-group col-lg-2">

                </div>
              </div>

          </div>
          <div class="panel panel-default">
            <div class="panel-body">
              <div class="form-group col-lg-3">
                <a type="button" href="{{route('crear_colmena')}}" name="button" class="btn btn-warning btn-block">Crear Nueva Colmena</a>
              </div>
              <div class="form-group col-lg-3">
               <button type="button" name="button" class="btn btn-warning btn-block" onclick="PruebaAlert()">Generar Codigo QR</button>
              </div>
              <div class="form-group col-lg-3">
              <!-- <button type="button" name="button" class="btn btn-warning btn-block" onclick="PruebaAlert();">Ver Resumen</button>-->
              </div>
            </div>
          </div>
       </div>
    </div>
    <!--reinas instaladas -->
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">COLMENAS</h3>

        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Mostrar Tabla">
            <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Quitar Tabla">
              <i class="fa fa-times"></i></button>
        </div>
        </div>
          <div class="box-body" style="font-size:11px; text-align:center; cursor: pointer" id="contenedor_tabla_inst">
            @foreach ($apiario as $key => $row)


              <div class="panel panel-info">
                <div class="panel-heading">
                  <h4 class="panel-tittle">Apiario {{$row->nombre_apiario}}</h4>
                  <!--<button type="button" name="button" class="btn btn-success btn-xs pull-right">Agregar Colmena</button>-->
                </div>
                <div class="panel-body">

                      <table class="table table-condensed table-striped tbl" id="{{$row->idapiario}}">
                        <thead>
                          <th>#</th>
                          <th>Colmena</th>
                          <th>Descripción</th>
                          <th>Reina</th>
                          <th>Fecha Creación</th>
                          <th>Acciones</th>
                        </thead>
                        <tbody>
                        @php
                          $contador=0;
                        @endphp
                        @foreach ($colmenas as $key => $row1)

                          @if ($row->idapiario==$row1->idapiario)
                            @php
                              $contador++;
                            @endphp
                          <tr>
                            <td >{{$contador}}</td>
                            <td >{{$row1->identificador_colmena}}</td>
                            <td >{{$row1->descripcion}}</td>
                            @if ($row1->idreinas=="" || is_null($row1->idreinas))
                              <td ><span class="text-danger" onclick="ModalAsignarReina({{$row1->idcolmenas}});">Sin Asignar</span> </td>
                            @else
                              <td><button class="btn btn-success btn-xs" type="button" onclick="modalDetalleReina({{$row1->idreinas}},{{$row1->idcolmenas}});">{{$row1->identificador_reina}}</button></td>
                            @endif
                            <td>{{$row1->created_at}}</td>
                            <td>
                            <button type="button" name="button" class="btn btn-warning btn-xs" onclick="VerComponentes({{$row1->idcolmenas}});" ><i class="glyphicon glyphicon-oil"></i> Componentes</button>
                            <button type="button" name="button" class="btn btn-primary btn-xs" onclick="DetalleColmena({{$row1->idcolmenas}});"><i class="glyphicon glyphicon-eye-open"></i> Detalle</button>
                            <button type="button" name="button" class="btn btn-info btn-xs" onclick="nuevaInspeccionColmena({{$row1->idcolmenas}})"><i class="	glyphicon glyphicon-zoom-in"></i> Inspeccionar</button>
                            <button type="button" name="button" class="btn btn-warning btn-xs" onclick="gestionEventos({{$row1->idcolmenas}});"><i class="glyphicon glyphicon-globe"></i> Eventos</button>
                            <button type="button" name="button" class="btn btn-info btn-xs" onclick="EditarColmena({{$row1->idcolmenas}})" ><i class="glyphicon glyphicon-pencil"></i></button>
                            <button type="button" name="button" class="btn btn-danger btn-xs" onclick="EliminarColmena({{$row1->idcolmenas}},{{$row1->idreinas}})" ><i class="glyphicon glyphicon-trash"></i> </button>
                          </td>
                          </tr>
                        @endif
                      @endforeach
                        </tbody>
                      </table>
                </div>
              </div>
            @endforeach

        </div>
    </div>
  <script src="{{ asset('js/colmenas.js') }}" defer></script>
@endsection

<div class="panel panel-primary">
  <h1>mi primer Reporte</h1>
</div>

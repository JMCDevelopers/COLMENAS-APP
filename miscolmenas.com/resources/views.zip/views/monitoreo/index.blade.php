@extends('layouts/dashboard')
@section('contenido')
  monitoreo
  <script src="{{ asset('js/monitoreo.js') }}" defer></script>
@endsection

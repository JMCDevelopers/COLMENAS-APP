<?php

namespace App\Http\Controllers\Test;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mail;
class TestController extends Controller
{


    public function testEmail(){
      $data=array(
        'name'=>'test email',
      );
      Mail::send('emails/confirm_account',$data,function($msj){
          $msj->subject('Confimacion de cuenta');
          $msj->to('juan.gabriel.077@gmail.com');
      });
      return "ok";
    }
}

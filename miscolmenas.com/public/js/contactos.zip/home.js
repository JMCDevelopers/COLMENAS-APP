$(document).ready(function() {

  $("#index").addClass("colorlib-active");
});

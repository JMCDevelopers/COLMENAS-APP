$(document).ready(function() {

  $("#noticias").addClass("colorlib-active");
});

$(document).ready(function() {

  $("#login_inicio").addClass("colorlib-active");
});

$(document).ready(function() {

  $("#descargas").addClass("colorlib-active");
});
